// script.js

function performSearch() {
    const searchQuery = document.getElementById('search').value.toLowerCase();
    const resultsContainer = document.getElementById('results-container');

    // Example data to simulate a database
    const data = [
        { title: 'Faculty', content: 'Information about faculty members.' },
        { title: 'Student Section', content: 'Details on student resources and sections.' },
        { title: 'Fee Structure', content: 'Breakdown of fee structure and payment details.' },
    ];

    // Clear previous results
    resultsContainer.innerHTML = '';

    // Filter results based on the search query
    const results = data.filter(item => 
        item.title.toLowerCase().includes(searchQuery) || 
        item.content.toLowerCase().includes(searchQuery)
    );

    // Display results
    if (results.length > 0) {
        results.forEach(result => {
            const resultElement = document.createElement('div');
            resultElement.className = 'result-item';
            resultElement.innerHTML = `<h3>${result.title}</h3><p>${result.content}</p>`;
            resultsContainer.appendChild(resultElement);
        });
    } else {
        resultsContainer.innerHTML = '<p>No results found.</p>';
    }
}
