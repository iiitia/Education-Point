document.addEventListener('DOMContentLoaded', (event) => {
    // Function to handle form submission
    function handleSubmit(event) {
        event.preventDefault(); // Prevent default form submission
        
        // Hide the form and show the success message
        document.getElementById('contact-form').style.display = 'none';
        document.getElementById('success-message').style.display = 'block';
    }

    // Attach the handleSubmit function to the form's submit event
    document.getElementById('contact-form').addEventListener('submit', handleSubmit);
});
